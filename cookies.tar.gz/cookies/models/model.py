class User:
    def __init__(self,user,senha,tipo):
        self.user=user
        self.senha=senha
        self.tipo=tipo
usuarios=[]
usuarios.append({'Nome':"Guilherme",'Senha':'1234','Tipo':'user'})
usuarios.append({'Nome':"Vinicius",'Senha':'5678','Tipo':'admin'})
verificacao=""


