from database import db
from sqlalchemy import Date, DateTime, func, Enum

class Historico(db.Model):
    __tablename__ = 'historico'

    id = db.Column(db.Integer,primary_key = True)
    preco = db.Column(db.float, nullable = False)
    data_checkin = db.Column(db.DateTime, nullable=False)
    data_checkout = db.Column(db.DateTime, nullable=False)
    servico = db.Column(db.String(80),nullable = False)
    # id_quarto=
    # tipo_quarto=

    # id_cliente=
    # id_funcionario=