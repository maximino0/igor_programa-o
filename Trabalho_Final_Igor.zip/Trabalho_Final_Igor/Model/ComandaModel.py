from database import db
from sqlalchemy import Date, DateTime, func, Enum

class Cliente(db.Model):
    __tablename__ = 'cliente'

    id = db.Column(db.Integer,primary_key = True)
    preo_estadias = db.Column(db.Float,nullable = False)
    preco_frigobar = db.Column(db.Float,nullable = True)
    preco_servicos = db.Column(db.Float,nullable = True)