from database import db
from sqlalchemy import Date, DateTime, func, Enum

class Quarto(db.Model):
    __tablename__ = 'quarto'

    numero = db.Column(db.Integer,primary_key = True)
    tipo = db.Column(db.String(64), nullable = False)
    preco = db.Column(db.float, nullable = False)

    
    