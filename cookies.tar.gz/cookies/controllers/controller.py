from flask import Flask, Blueprint, render_template,request,redirect,url_for,session

from models.model import*

login_controller=Blueprint('login',__name__)

@login_controller.before_request
def request_info():
    print("Executa antes da requisição")

@login_controller.after_request
def response_info(response):
    print("Executa antes da resposta")
    return response
@login_controller.route('/')
def index():
    return render_template('index.html',usuarios=usuarios,verificacao=verificacao)

@login_controller.route("/user", methods=['POST','GET'])
def ver():
    if request.method == 'POST':
        session.permanent = True
        session['nome']=request.form['nome']
        session['senha']=request.form['Senha']
        for i in usuarios:
            if (i['Nome']==session['nome'] and i['Senha']==session['senha']):
                session['Tipo']=i['Tipo']
                verificacao=f'<p>Você foi conectado com sucesso {i["Nome"]}, você é um {i["Tipo"]}</p>'
                return render_template('tipo1.html',verificacao=verificacao)
        verificacao=f'<p>Esse usuário não existe</p>'
        return render_template('index.html',usuarios=usuarios,verificacao=verificacao)
    else:
        verificacao=f'<p>Você foi conectado com sucesso {session["nome"]}, você é um {session["Tipo"]}</p>'
        return render_template('tipo1.html',usuarios=usuarios,verificacao=verificacao)

@login_controller.route("/logout", methods=['POST'])
def logout():
    session.pop('nome',None)
    session.pop('senha',None)
    return redirect(url_for('login.index'))
