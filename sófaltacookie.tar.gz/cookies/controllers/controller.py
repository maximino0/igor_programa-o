from flask import Flask, Blueprint, render_template,request,redirect,url_for,session,make_response,get_flashed_messages,flash,abort

from models.model import*

login_controller=Blueprint('login',__name__)
rotas_publicas=['login.index','login.ver']
rotas_admin=[]
@login_controller.before_request
def request_info():
    if request.endpoint in rotas_publicas:
        return 
    if ('User' not in session):
        abort(403)
    else:
        if 'Tipo'!= "admin" and request.endpoint in rotas_admin:
            abort(401)
    return
@login_controller.route('/')
def index():
    session.pop('User',None)
    session.pop('Tipo',None)
    session.pop('Id',None)
    return render_template('index.html',usuarios=usuarios,verificacao=verificacao)

@login_controller.route("/user", methods=['POST','GET'])
def ver():
    if request.method == 'POST':
        session.permanent = True
        for i in usuarios:
            if (i.user==request.form['user'] and i.senha==request.form['Senha']):
                session['User']=request.form['user']
                session['Tipo']=i.tipo
                session['Id']=i.Id
                verificacao=f"<p>Você foi conectado com sucesso {session['User']}, você é um {session['Tipo']}</p>"
                flash(f"Login realizado com sucesso {session['User']}!","success")
                return render_template('tipo1.html')
        flash("Login não foi realizado com sucesso!","error")
        return redirect(url_for("login.index"))
    else:
        if session["User"] and session["Tipo"]:
            verificacao=f'<p>Você foi conectado com sucesso {session["User"]}, você é um {session["Tipo"]}</p>'
            return render_template('tipo1.html',usuarios=usuarios,verificacao=verificacao)

@login_controller.route("/logout", methods=['POST'])
def logout():
    session.pop('User',None)    
    session.pop('Tipo',None)
    session.pop('Id',None)
    flash("Você saiu com sucesso.","success")
    return   redirect(url_for('login.index'))

